"use strict";

module.exports = {
	lazy: require("./lazy")
};
