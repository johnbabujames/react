"use strict";

module.exports = function (value) {
	return function () {
		return value;
	};
};
