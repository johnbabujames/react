'use stirct';

module.exports = require('./async').mapValuesLimit;
