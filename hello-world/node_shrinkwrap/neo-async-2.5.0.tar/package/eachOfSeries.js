'use stirct';

module.exports = require('./async').eachOfSeries;
