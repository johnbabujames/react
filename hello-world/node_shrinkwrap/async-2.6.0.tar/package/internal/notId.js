"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = notId;
function notId(v) {
    return !v;
}
module.exports = exports["default"];