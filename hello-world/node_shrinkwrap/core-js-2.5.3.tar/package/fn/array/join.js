require('../../modules/es6.array.join');
module.exports = require('../../modules/_core').Array.join;
