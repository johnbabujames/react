require('../../modules/es6.array.some');
module.exports = require('../../modules/_core').Array.some;
