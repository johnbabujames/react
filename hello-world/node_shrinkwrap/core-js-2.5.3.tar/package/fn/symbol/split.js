require('../../modules/es6.regexp.split');
module.exports = require('../../modules/_wks-ext').f('split');
