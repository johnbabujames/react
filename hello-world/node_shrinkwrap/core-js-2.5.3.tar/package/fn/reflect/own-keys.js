require('../../modules/es6.reflect.own-keys');
module.exports = require('../../modules/_core').Reflect.ownKeys;
