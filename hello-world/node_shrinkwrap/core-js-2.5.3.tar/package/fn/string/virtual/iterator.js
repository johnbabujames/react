require('../../../modules/es6.string.iterator');
module.exports = require('../../../modules/_iterators').String;
