require('../../modules/es7.math.scale');
module.exports = require('../../modules/_core').Math.scale;
