require('../../modules/es6.object.is-frozen');
module.exports = require('../../modules/_core').Object.isFrozen;
