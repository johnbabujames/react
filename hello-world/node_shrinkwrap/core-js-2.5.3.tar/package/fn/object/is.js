require('../../modules/es6.object.is');
module.exports = require('../../modules/_core').Object.is;
