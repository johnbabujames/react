require('../modules/core.delay');
module.exports = require('../modules/_core').delay;
